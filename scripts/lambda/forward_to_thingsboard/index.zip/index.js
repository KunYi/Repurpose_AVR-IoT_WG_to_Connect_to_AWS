var rp = require('request-promise');

exports.handler = async (event) => {
    var options = {
        method: 'POST',
        uri: 'https://demo.thingsboard.io/api/v1/<ACCESS_TOKEN>/telemetry',
        body: {
            L: event.L,
            T: event.T,
        },
        json: true,
    };

    rp(options)
      .then(function (parsedBody) {
          console.log("success ->", parsedBody);
      })
      .catch(function (err) {
          console.log("fails -> ", err);
      });
};
